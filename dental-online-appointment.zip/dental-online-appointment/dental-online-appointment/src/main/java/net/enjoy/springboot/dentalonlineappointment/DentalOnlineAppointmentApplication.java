package net.enjoy.springboot.dentalonlineappointment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DentalOnlineAppointmentApplication {

    public static void main(String[] args) {
        SpringApplication.run(DentalOnlineAppointmentApplication.class, args);
    }
}
